package com.mlbb.emailcodesender.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mlbb.emailcodesender.utils.MoontonCodeApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CodeViewModel : ViewModel() {

    private val _status = MutableLiveData<String>("idle")
    val status: LiveData<String> = _status

    private val _result = MutableLiveData<String>("")
    val result: LiveData<String> = _result

    private val _busy = MutableLiveData(false)
    val busy: LiveData<Boolean> = _busy

    /** Latest extracted verification code for direct UI display. */
    private val _code = MutableLiveData<String>("")
    val code: LiveData<String> = _code

    fun sendCode(email: String) {
        if (_busy.value == true) return
        _busy.value = true
        _status.value = "sending…"
        _result.value = ""
        _code.value = ""
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                MoontonCodeApi.sendEmailVerificationCode(email)
            }
            _busy.value = false
            if (r.success && r.extractedCode.isNotBlank()) {
                _status.value = "SUCCESS — code in app"
                _code.value = r.extractedCode
            } else if (r.success) {
                _status.value = "SUCCESS — request accepted (check raw / email)"
                _code.value = ""
            } else {
                _status.value = "failed / probe complete"
                _code.value = ""
            }
            _result.value = MoontonCodeApi.describe(r)
        }
    }

    fun loginTest(email: String, password: String) {
        if (_busy.value == true) return
        _busy.value = true
        _status.value = "login…"
        _result.value = ""
        _code.value = ""
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                MoontonCodeApi.login(email, password)
            }
            _busy.value = false
            _status.value = if (r.success) "LOGIN OK" else "login failed"
            _result.value = MoontonCodeApi.describe(r)
        }
    }
}
