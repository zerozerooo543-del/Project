package com.mlbb.emailcodesender

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.mlbb.emailcodesender.viewmodel.CodeViewModel

class MainActivity : AppCompatActivity() {

    private val vm: CodeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnSend = findViewById<Button>(R.id.btnSendCode)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val tvCode = findViewById<TextView>(R.id.tvCode)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val scroll = findViewById<ScrollView>(R.id.scrollResult)

        vm.status.observe(this) { tvStatus.text = it }
        vm.code.observe(this) { code ->
            if (code.isNullOrBlank()) {
                tvCode.text = "—"
                tvCode.setTextColor(0xFF6E7681.toInt())
            } else {
                tvCode.text = code
                tvCode.setTextColor(0xFF3FB950.toInt())
            }
        }
        vm.result.observe(this) {
            tvResult.text = it
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
        vm.busy.observe(this) { busy ->
            btnSend.isEnabled = !busy
            btnLogin.isEnabled = !busy
        }

        btnSend.setOnClickListener {
            val email = etEmail.text?.toString().orEmpty()
            vm.sendCode(email)
        }

        btnLogin.setOnClickListener {
            val email = etEmail.text?.toString().orEmpty()
            val pass = etPassword.text?.toString().orEmpty()
            vm.loginTest(email, pass)
        }
    }
}
