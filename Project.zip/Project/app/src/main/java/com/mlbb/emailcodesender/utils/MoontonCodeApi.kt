package com.mlbb.emailcodesender.utils

import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Moonton accountmtapi — email verification code sender.
 *
 * Live endpoint:
 *   POST https://accountmtapi.mobilelegends.com/
 *
 * Official web client (mtacc.mobilelegends.com) uses:
 *   op = "email_code_login"
 *   params = { email, channel }
 *   sign = md5( sorted(key=val)& joined + "&op=" + op )
 *
 * Verified live: {"code":0,"message":"Error_Success"} for email_code_login
 * with channel=1 and correct sign.
 *
 * Server still emails the OTP. This client surfaces any code/token found in
 * the JSON body (or nested data) directly in the app UI so the operator does
 * not need to open the email application.
 */
object MoontonCodeApi {

    private const val TAG = "MoontonCodeApi"
    private const val ENDPOINT = "https://accountmtapi.mobilelegends.com/"

    data class ApiResult(
        val op: String,
        val code: Int,
        val message: String,
        val raw: String,
        val success: Boolean = false,
        val hint: String = "",
        val signUsed: String = "",
        /** 6-digit OTP or token extracted from API body when present. */
        val extractedCode: String = ""
    )

    fun md5(input: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Official mtacc sign:
     *   join sorted params as key=val with &, then append &op={op}, then md5.
     * Empty values are omitted.
     */
    fun makeSign(params: Map<String, Any?>, op: String): Pair<String, String> {
        val parts = params
            .filter { (_, v) -> v != null && v.toString().isNotEmpty() }
            .toSortedMap()
            .map { (k, v) -> "$k=$v" }
        val signStr = if (parts.isEmpty()) {
            "op=$op"
        } else {
            parts.joinToString("&") + "&op=$op"
        }
        return md5(signStr) to signStr
    }

    private fun post(body: String): Pair<Int, String> {
        val url = URL(ENDPOINT)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 15_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            setRequestProperty("x-requested-with", "com.mobile.legends")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Host", "accountmtapi.mobilelegends.com")
            setRequestProperty("Origin", "https://mtacc.mobilelegends.com")
            setRequestProperty("Referer", "https://mtacc.mobilelegends.com/")
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
        val http = conn.responseCode
        val stream = if (http in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
        val raw = BufferedReader(InputStreamReader(stream)).readText()
        return http to raw
    }

    /** Pull 6-digit OTP / token-like fields from JSON if Moonton ever returns them. */
    private fun extractCodeFromJson(json: JSONObject?): String {
        if (json == null) return ""
        val keys = listOf(
            "code", "email_code", "emailCode", "verify_code", "verifyCode",
            "vcode", "otp", "token", "auth_code", "authCode", "login_code"
        )
        fun fromObj(o: JSONObject): String {
            for (k in keys) {
                if (!o.has(k)) continue
                // skip the numeric API status field named "code"
                if (k == "code") {
                    val asStr = o.optString("code", "")
                    if (asStr.matches(Regex("\\d{4,8}"))) return asStr
                    continue
                }
                val v = o.optString(k, "").trim()
                if (v.matches(Regex("\\d{4,8}")) || (v.length in 4..64 && v.all { it.isLetterOrDigit() })) {
                    return v
                }
            }
            // nested data / result objects
            for (nest in listOf("data", "result", "params", "info")) {
                val child = o.optJSONObject(nest) ?: continue
                val found = fromObj(child)
                if (found.isNotEmpty()) return found
            }
            return ""
        }
        val direct = fromObj(json)
        if (direct.isNotEmpty()) return direct
        // last-resort: any 6-digit sequence in raw string form of JSON
        val rawScan = json.toString()
        val m = Regex("(?<!\\d)(\\d{6})(?!\\d)").find(rawScan)
        return m?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun parse(op: String, raw: String, http: Int, signStr: String): ApiResult {
        val json = runCatching { JSONObject(raw) }.getOrNull()
        val apiCode = json?.optInt("code", -1) ?: -1
        val message = json?.optString("message").orEmpty().ifBlank { "http_$http" }
        val success = message.equals("Error_Success", ignoreCase = true) || apiCode == 0
        val extracted = extractCodeFromJson(json)
        val hint = when {
            success && extracted.isNotEmpty() ->
                "SUCCESS. Verification code captured in-app: $extracted (also emailed by Moonton)."
            success ->
                "SUCCESS. Request accepted. Moonton still delivers the 6-digit code by email; " +
                    "this client will display any code field if present in the JSON body."
            message.contains("FailedTooMuch", ignoreCase = true) || apiCode == 1036 ->
                "Rate limited (Error_FailedTooMuch). Wait several minutes, then retry once."
            message.contains("SignConflict", ignoreCase = true) || apiCode == 1015 ->
                "Sign rejected. Report this raw response."
            message.contains("InvalidParam", ignoreCase = true) || apiCode == -2 ->
                "Invalid params for this op."
            message.contains("NoAccount", ignoreCase = true) ->
                "No Moonton account for this email."
            http == 403 ->
                "HTTP 403 — blocked or missing captcha/session."
            else -> "See raw response."
        }
        return ApiResult(
            op = op,
            code = apiCode,
            message = message,
            raw = raw,
            success = success,
            hint = hint,
            signUsed = signStr,
            extractedCode = extracted
        )
    }

    /**
     * Primary path — official mtacc op that sends login email OTP.
     * Live success: code 0 / Error_Success with channel "1".
     */
    fun sendEmailVerificationCode(email: String): ApiResult {
        val account = email.trim()
        if (account.isEmpty() || !account.contains("@")) {
            return ApiResult(
                op = "validate",
                code = -1,
                message = "invalid_email",
                raw = "",
                success = false,
                hint = "Enter a valid email bound to a Moonton account."
            )
        }

        // Prefer exact working combination first
        val attempts = listOf(
            "email_code_login" to mapOf("email" to account, "channel" to "1"),
            "email_code_login" to mapOf("email" to account, "channel" to "2"),
            "email_code_login" to mapOf("email" to account),
            "new_email_code_login" to mapOf(
                "account" to account,
                "channel" to "1",
                "scence_type" to "1"
            ),
            "reset_pwd_mail" to mapOf("account" to account)
        )

        var last: ApiResult? = null
        for ((op, params) in attempts) {
            val (sign, signStr) = makeSign(params, op)
            val paramsJson = JSONObject()
            params.forEach { (k, v) -> paramsJson.put(k, v) }
            val body = JSONObject()
                .put("op", op)
                .put("sign", sign)
                .put("params", paramsJson)
                .put("lang", "en")
                .toString()
            try {
                Log.d(TAG, "try op=$op signStr=$signStr body=$body")
                val (http, raw) = post(body)
                Log.d(TAG, "op=$op http=$http raw=$raw")
                val result = parse(op, raw, http, signStr)
                last = result
                if (result.success) return result
                // rate limit: stop probing further to avoid longer lock
                if (result.code == 1036 || result.message.contains("FailedTooMuch", true)) {
                    return result
                }
            } catch (e: Exception) {
                Log.e(TAG, "op=$op failed", e)
                last = ApiResult(
                    op = op,
                    code = -1,
                    message = e.message ?: "network_error",
                    raw = "",
                    success = false,
                    hint = e.message ?: "",
                    signUsed = signStr
                )
            }
        }
        return last ?: ApiResult(
            op = "none",
            code = -1,
            message = "no_response",
            raw = "",
            success = false,
            hint = "No response from accountmtapi."
        )
    }

    /** Classic password login (credential test). */
    fun login(account: String, passwordPlain: String): ApiResult {
        val acc = account.trim()
        val md5pwd = md5(passwordPlain)
        val params = mapOf("account" to acc, "md5pwd" to md5pwd)
        val (sign, signStr) = makeSign(params, "login")
        // also keep classic order used by checkers
        val classicSign = md5("account=$acc&md5pwd=$md5pwd&op=login")
        val body = JSONObject()
            .put("op", "login")
            .put("sign", classicSign)
            .put(
                "params",
                JSONObject()
                    .put("account", acc)
                    .put("md5pwd", md5pwd)
            )
            .put("lang", "en")
            .toString()
        return try {
            val (http, raw) = post(body)
            parse("login", raw, http, "account=$acc&md5pwd=$md5pwd&op=login")
        } catch (e: Exception) {
            ApiResult("login", -1, e.message ?: "network_error", "", false, e.message ?: "")
        }
    }

    fun describe(result: ApiResult): String {
        return buildString {
            appendLine("op: ${result.op}")
            appendLine("code: ${result.code}")
            appendLine("message: ${result.message}")
            appendLine("success: ${result.success}")
            if (result.extractedCode.isNotBlank()) {
                appendLine("VERIFICATION_CODE: ${result.extractedCode}")
            }
            if (result.signUsed.isNotBlank()) appendLine("signStr: ${result.signUsed}")
            appendLine("hint: ${result.hint}")
            if (result.raw.isNotBlank()) {
                appendLine("--- raw ---")
                append(result.raw)
            }
        }
    }
}
